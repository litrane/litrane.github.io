# HuxBlog Boilerplate

##### This is the boilerplate of [Hux Blog](https://github.com/Huxpro/huxpro.github.io), all documents is over there!

#### [View Boilerplate &rarr;](http://huangxuan.me/huxblog-boilerplate/)

#### [View Live Hux Blog &rarr;](http://huangxuan.me)

## If you like Hux Blog, Please star [huxpro.github.io repo](https://github.com/Huxpro/huxpro.github.io) instead of this! Thank you!